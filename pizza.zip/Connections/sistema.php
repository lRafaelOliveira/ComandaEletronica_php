<?php
ini_set('display_errors', 0 );
error_reporting(0);
?>
<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_sistema = "localhost";
$database_sistema = "santosja_piz";
$username_sistema = "santosja_piz";
$password_sistema = "9437santos";
$sistema = mysql_connect($hostname_sistema, $username_sistema, $password_sistema) or trigger_error(mysql_error(),E_USER_ERROR); 
?>