<ul id="css3menu1" class="topmenu">
	<li><a href="inicio.php" ><img src="imagens/Home-icon.png" width="40" alt="Inicio"/>Inicio</a></li>
	<li><a href="inicio.php?btn=config"><img src="imagens/pic_3.png" width="40" alt=""/>Configurações</a>
    
     <ul>
     		<li><a href="inicio.php?btn=config">Configurações</a></li>
            <li><a href="inicio.php?btn=cadastroProdutos">Cadastro de Produto</a></li>
            <li><a href="inicio.php?btn=alterapreco">Alterar Precos / Excluir</a></li>
            <li><a href="inicio.php?btn=cadastromesa">Cadastrar Mesas</a></li>
            <li><a href="inicio.php?btn=cadastroclientes">Cadastrar Clientes</a></li>
            <li><a href="inicio.php?btn=cadGarcon">Cadastro de Usuários</a></li>
            <li><a href="inicio.php?btn=categoria">Categoría de Produtos</a></li>
        </ul>
    
    </li>
	<!-- <li><a href="?btn=nova"><img src="imagens/dinheiro.png" alt=""/>Vendas de Balcão</a></li> -->
    <li><a href="inicio.php?btn=mesa"><img src="imagens/mesas.png" width="40" alt=""/>Mesas</a></li>
    
   <li><a href="inicio.php?btn=garcon"><img src="imagens/money.png" width="40" alt=""/>Vendas</a></li>
      
	
    
    <li><a href=""><img src="imagens/cadastro.png" width="40" alt=""/>Relatórios</a>
    <ul>
    <li><a href="pedidoscozinha.php">Cozinha</a></li>
	<li><a href="inicio.php?btn=relatorio">Relatório Geral</a></li>
    <li><a href="inicio.php?btn=relatoriogarcon">Relatório Garçom</a></li>
        </ul>
      </li>

    <li><a href="backup/backup.php"><img src="imagens/Burn 3.png" width="40" alt=""/>Backup</a></li>
	  <li><a href="inicio2.php?btn=entrega"><img src="imagens/restaurant.png" width="40" alt=""/>Entrega</a></li>
    <li><a href="sair.php"><img src="imagens/unsubscribe.png" width="40" alt=""/>Sair</a></li>
</ul>