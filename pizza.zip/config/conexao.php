<?phpini_set('display_errors', 0 );error_reporting(0);?><?php error_reporting(E_WARNING);
// ALTERE OS DADOS DAS STRINGS (NOMES QUE ESTÃO ENTRE AS ASPAS)
$host = "localhost"; // endereco do banco de dados
$usuario = "santosja_piz"; // usuario do banco de dados
$senhadobanco = "9437santos"; // senha do banco de dados
$nomedobanco = "santosja_piz"; //nome do banco de dados

// NÃO ATERAR NADA DAQUI PARA BAIXO
$db = mysql_connect($host,$usuario,$senhadobanco) or die (mysql_error());
$banco = mysql_select_db($nomedobanco,$db)or die (mysql_error());
mysql_set_charset('utf8');
?>
